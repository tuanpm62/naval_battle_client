Credit: Molly "Cougarmint" Willits
Created by hand using MS Paint and Photoshop Educational Edition 6.0.

Licence: CC-BY 3.0.

Free Commercial Use: Yes
Free Personal Use: Yes

Included in this Pack:
BattleShipSheet_final.png
oceangrid_final.png
radargrid_final.png
Tokens.png

Non-Transparent Folder:
BattleShipSheet_final_Non-transparent.png
tokens_non-transparent.png

Printable Folder:
PaperBattleShipGridandShips.png
PaperBattleShipTokens.png

Scraps Folder:
metalic_panel.png
oceangrid.png
radargrid.png

Donations: Not needed, but appreciated. Contact me if you'd like to make a donation.